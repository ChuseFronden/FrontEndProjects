import React, { Component } from 'react';
import './App.css';
import TodoTable from './TodoTable';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {description: '', date:'', todos: []}
  }

  inputChanged = (event) => {
    this.setState({[event.target.name]: event.target.value});
  }

  addTodo = (event) => {
  const annoying={
    description:this.state.description,
    date:this.state.date
  }
    event.preventDefault();
    
    this.setState({
      todos: [...this.state.todos, annoying]
    });
  }
  deleteTodo = (row) => {
    //const index = parseInt(event.target.id);
    this.setState({
      todos: this.state.todos.filter((todo, i) => i != row.index)
    });
    }
  

  render() {
    return (
      <div className="App">
        <div className="App-header">
        
          <h2>Simple Todolist</h2>
        </div>

        <div className="Apptodo">
        <div className="apptodop">
        <p>Add to do</p>
        </div>
        <div className="apptodo2">
          <form onSubmit={this.addTodo}>
          Description:
            <input type="text" name="description" onChange={this.inputChanged} value={this.state.description}/>
            Date:
            <input type="date" name="date" onChange={this.inputChanged} value={this.state.date}/>
            <input type="submit" value="Add"/>
          </form>
        </div> 
        </div>

      
        <TodoTable todos={this.state.todos} deleteTodo = {this.deleteTodo}/>
       
      </div>
    );
  }
}

export default App;
